import 'package:flutter/material.dart';

class Data {
  String images;
  String text;

  Data({required this.images, required this.text});
}
