class Screen {
  var page;
  Screen({required this.page});
}
