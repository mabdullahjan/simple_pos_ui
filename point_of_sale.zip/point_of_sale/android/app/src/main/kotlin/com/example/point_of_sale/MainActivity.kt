package com.example.point_of_sale

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
